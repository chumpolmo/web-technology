<?php
define("DB_HOST", "......");
define("DB_USERNAME", "......");
define("DB_PASSWORD", "......");
define("DB_DATABASE_NAME", "......");
?>
