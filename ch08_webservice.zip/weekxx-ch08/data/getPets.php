<?php
include("......");

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE_NAME);
$result = $conn->query("SELECT * FROM ......");

$outp = [];
while($obj = $result->fetch_object()) {
    $outp[] = $obj;
}
echo json_encode($outp);

$conn->close();
?>
