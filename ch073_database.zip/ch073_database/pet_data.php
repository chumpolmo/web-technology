<!DOCTYPE HTML>  
<html>
<head>
  <meta charset="utf-8" />
  <title>Week10: PHP MySQL By _Your name_</title>
  <script type="text/javascript" src="./js/myjs-xxxx-x.js"></script>
  <style type="text/css">
    .msg_form {
      color: red;
    }

    .topic {
      text-align: center;
      color: blue;
    }

    .section {
      margin: 25px;
    }

    table, th, td {
      border-collapse: collapse;
      border: 1px solid #CCCCCC;
    }
  </style>
</head>
<body>

<strong><a href="......................">หน้าแรก</a></strong>
<hr />
<h2 class="topic">รายการสัตว์เลี้ยง</h2>
<p>
<?php
include './libs/functions-xxxx-x.php';

......................

$sql = "......................";
$result = $conn->query($sql);

echo "<div style='text-align:right;padding:2px;'>ข้อมูล ".$result->num_rows." รายการ</div>";
echo "<table style='border:1px solid #CCCCCC;width:100%;'>";
echo "<tr><th rowspan='2'>รหัส</th><th rowspan='2'>ชื่อ</th><th rowspan='2'>ชนิด</th><th rowspan='2'>เพศ</th><th colspan='2'>ข้อมูลเจ้าของ</th><th rowspan='2'>หมายเหตุ</th></tr>";
echo "<tr><th>อีเมล</th><th>เบอร์ติดต่อ</th></tr>";

if (...................... > 0) {
  while(......................) {
    echo "<tr><td>" . ________________ . "</td>";
    echo "<td>" . ________________ . "</td>";
    echo "<td>" . ________________ . "</td>";
    echo "<td>xxx</td><td>xxx</td><td>xxx</td>";
    echo "<td>xxx</td></tr>";
  }
} else {
  echo "<tr><td colspan='7' style='text-align:center;'>ไม่มีข้อมูล</td></tr>";
}
echo "<table>";
?>
</p>
<?php
$con->close();
?>
</body>
</html>