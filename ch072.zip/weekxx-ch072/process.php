<!DOCTYPE HTML>  
<html>
<head>
  <meta charset="utf-8" />
  <title>Week09: PHP Form By __Your Name__</title>
  <style type="text/css">
    .msg_form {
      color: red;
    }

    .topic {
      text-align: center;
      color: blue;
    }

    .section {
      margin: 25px;
    }
  </style>
</head>
<body>

<?php
include '...(1)...';

// Define variables and set to empty values
$pname = "";
// ...(2)...

if ($_SERVER["REQUEST_METHOD"] == "POST" || isset($_POST['submit'])) {
  $pname = test_input($_POST["pet_name"]);
  $ptype = test_input($_POST["pet_type"]);
  $ptype = getPetType($ptype);

  if(isset($_POST["pet_gender"])){
    // ...(3)...
  }else{
    $pgender = test_input($pnote);
  }

  // ...(4)...
}

echo "<h2 class='topic'>ข้อมูลสัตว์เลี้ยง</h2>";
echo "<h3>ข้อมูลทั่วไป</h3><hr />";
echo "ชื่อ (Name): $pname<br />";
// ...(5)...
echo "<h3>ข้อมูลเจ้าของ</h3><hr />";
// ...(6)...

echo "<a href='...(7)...'>[ ย้อนกลับ ]</a>";
?>

</body>
</html>