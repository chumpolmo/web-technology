/***
 * Author: __Your name__
 * Student ID: xxxxxxxxxxxx-x
 * Function: ตรวจสอบข้อมูลนำเข้า
 **/
function formValidate(){
	var tmp = document.getElementById('pet_type').value;
	if(tmp === ""){
		alert("กรุณาเลือกประเภทของน้องด้วย!");
		document.getElementById('pet_type').focus();
		return false;
	}

	// เพิ่มสคริปต์สำหรับตรวจสอบข้อมูลอื่นตามที่ระบุ (*)
	// ...(1)...

	return true;
}