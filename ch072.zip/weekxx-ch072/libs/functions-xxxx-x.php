<?php
/***
 * Author: __Your name__
 * Student ID: xxxxxxxxxxxx-x
 * Function: ตรวจสอบข้อมูลนำเข้าและเรียกดูข้อมูลประเภทสัตว์เลี้ยง
 **/
function test_input($data) {
  // ...(1)...
}

function getPetType($t){
  $tmp = "";
  switch ($t) {
  	case 10:
  		$tmp = "สุนัข";
  		break;
    // ...(2)... - เพิ่มการตรวจสอบเงื่อนไขของกรณีอื่น ๆ
  	default:
  		$tmp = "ไม่ระบุ";
  		break;
  }
  return $tmp;
}

// ...(3)... - สร้างฟังก์ชันสำหรับตรวจสอบเพศของน้อง
?>