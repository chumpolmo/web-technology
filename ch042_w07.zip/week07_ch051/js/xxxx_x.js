/* 
 * Function: JavaScript form validation
 * Student ID: xxxxxxxxxxxx-x
 * Author: Your Name
 * Thank you: https://www.w3schools.com/howto/howto_js_scroll_to_top.asp
 */
function ...(4)...() {
  var x = document.getElementById("demo");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}

// Get the button
let mybutton = document.getElementById("myBtn").style;

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.display = "block";
  } else {
    mybutton.display = "none";
  }
}

function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
