<?php
	// Program:	xxxx
	// Author: xxxxxxxxxxxx-x
	
	// Creating a simple custom function
	// Enjoy.
?>