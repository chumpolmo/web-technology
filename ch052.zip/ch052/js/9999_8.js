/* 
 * Function: JavaScript form validation
 * Student ID: 026599999999-8
 * Author: Chumpol Mokarat
 */
function calTax(){
	// Coding starts here.
    const per = 100;
    let in_come = document.getElementById('income').value; // var
    let vat = 0;
    let tax = 0.0;
    if (in_come >= 0 && in_come <= 150000) {
        vat = 0;
    } else if(in_come >= 150001 && in_come <= 300000) {
        vat = 5;
    } else if(in_come >= 300001 && in_come <= 500000) {
        vat = 10;
    } else {
        vat = 15;
    }
    tax = in_come * (vat/per);
    document.getElementById('msgout').innerHTML = tax;
}

function getInfo(){
    let txt = "";
    let my_name = document.getElementById('myname').value;
    let my_day = document.getElementById('myday').value;
    let my_month = document.getElementById('mymonth').value;
    let my_year = document.getElementById('myyear').value;
    let my_addr = document.getElementById('myaddr').value;

    // true or false
    let my_class0 = document.getElementById('myclass0').checked;
    let my_class1 = document.getElementById('myclass1').checked;
    let my_class2 = document.getElementById('myclass2').checked;
    let my_chan0 = document.getElementById('mychan0').checked;
    let my_chan1 = document.getElementById('mychan1').checked;
    let my_chan2 = document.getElementById('mychan2').checked;

    txt+= "ข้อมูลผู้ใช้\n--\n\n";
    txt+= "ชื่อ-สกุล: "+my_name+"\n";
    txt+= "วัน/เดือน/ปี เกิด: "+my_day+"/"+my_month+"/"+my_year+"\n";
    txt+= "ที่อยู่: "+my_addr+"\n\n";
    txt+= "--Thank you--";

    alert(txt);
    //console.log("Hi!");
    //document.write("สวัสดี!");
}
