<?php
	// Program:	xxxx
	// Author: xxxxxxxxxxxx-x

	// phpinfo — Outputs information about PHP's configuration
	phpinfo();
?>